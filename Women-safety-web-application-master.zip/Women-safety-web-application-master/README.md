# Women-safety-web-application

A Dynamic web project for women safety and security with auto location tracking.